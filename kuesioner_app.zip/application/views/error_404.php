<div class="container" style="padding: 14vh 0; display: block;scroll-snap-align: start;">
	<div class="card" style="width: 100%;">
	  <div class="card-body" style="text-align:center;">
	  	<div style="width: 100%;
text-align: center;
margin: 2vh 0;">
	  		<img src="<?php echo base_url().'assets/images/logo_perusahaan.png' ?>" height="50" style="margin: auto;">
	  	</div>
	  	<h4>404 Not Found</h4>
	  	<p>Mohon maaf, the page you're looking for is not disini</p>
	  </div>
	</div>
</div>